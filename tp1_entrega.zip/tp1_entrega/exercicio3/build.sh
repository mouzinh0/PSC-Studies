
gcc -g -Wall get_val_ptr_test.c get_val_ptr_asm.s ../invoke/invoke.s -o get_val_ptr_test
