
gcc -g -Wall my_memcmp_test.c my_memcmp_asm.s ../invoke/invoke.s -o my_memcmp_test
