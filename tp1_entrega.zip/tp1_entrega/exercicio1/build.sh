
gcc -g -Wall rotate_right_test.c rotate_right_asm.s ../invoke/invoke.s -o rotate_right_test
