
gcc -g -Wall array_remove_cond_test.c array_remove_cond_asm.s less_than.s ../invoke/invoke.s -o array_remove_cond_test
